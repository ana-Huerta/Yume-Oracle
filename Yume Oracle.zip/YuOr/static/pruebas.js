document.addEventListener("DOMContentLoaded", () => cargarComunidad());

async function interpretar() {
    const palabras = document.getElementById("palabras").value.split(",");
    const metodo = document.getElementById("metodo").value;

    const res = await fetch("http://localhost:3000/api/interpretar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ palabras, metodo })
    });

    const data = await res.json();
    document.getElementById("resultado").textContent = data.mensaje || data.map(s => s.interpretacion).join(", ");
}

async function compartir() {
    const usuario = document.getElementById("usuario").value;
    const palabras = document.getElementById("palabras").value.split(",");
    const metodo = document.getElementById("metodo").value;
    const interpretacion = document.getElementById("resultado").textContent;

    await fetch("http://localhost:3000/api/compartir", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ usuario, palabras, interpretacion, metodo })
    });

    alert("Sueño compartido con éxito");
    cargarComunidad();
}

async function cargarComunidad() {
    const res = await fetch("http://localhost:3000/api/comunidad");
    const sueños = await res.json();

    const lista = document.getElementById("comunidad");
    lista.innerHTML = "";
    sueños.forEach(s => {
        const li = document.createElement("li");
        li.textContent = `${s.usuario}: ${s.interpretacion}`;
        lista.appendChild(li);
    });
}
