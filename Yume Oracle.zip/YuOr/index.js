const express = require('express');
const fs = require('fs').promises; // Se usa para leer el archivo json
const app = express();
const cos = require('cors');

//Para que los request sean en formato json
app.use(express.json());

// Configurar el directorio para archivos estáticos
app.use(express.static('static'));

//Funcion para cargar los sueños desde el archivo json
async function connection() {
    try {
        const data = await fs.readFile('suenos.json', 'utf-8');
        return JSON.parse(data); // Convertir a objeto JavaScript
    } catch (error) {
        console.error('Error al leer el archivo: ', error);
        return [];
    }
}

//Mostrar el index
app.get('/', (req, res) => {
    res.sendFile('static/index.html');
});


//Obtener una interpretacion de los sueños desde el json
app.get('/interpretar', async (req, res) => {
    const sueños = await connection();
    res.json(sueños);
});

// Puerto de la aplicación
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Escuchando en el puerto ${port}...`));