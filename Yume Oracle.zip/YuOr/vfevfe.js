const express = require('express');
const { parse } = require('path');
const app = express();

//Todo los request van a ser en formato json
app.use(express.json());

//Mini base -> se va a hacer un json
const s = [
    {id:1, name:'Ana', age:19, major:'TI'},
    {id:2, name:'Toya', age:19, major:'Music'},
    {id:3, name:'Dan Heng', age:21, major:'Photo'},
    {id:4, name:'Kaeya', age:22, major:'Actor'},
];

//Ruta del index
app.get('/', (req, res)=>{
    res.send('Node js api');
});

//Imprimir los estudiantes
app.get('/api/students', (req, res)=>{
    res.send(s);
});

//Llamar a un estudiante por un parametro
app.get('/api/students/:id', (req, res)=>{
    const students = s.find(c => c.id === parseInt(req.params.id));
    if (!students) return res.status(404).send('Estudiante no encontrado');
    else res.send(students);
});

//Agregar estudiante
app.post('/api/students', (req, res) =>{
    const students = {
        id: s.lenght + 1,
        name: req.body.name,
        age: parseInt(req.body.age),
        major: (req.body.major)
    };

    s.push(students);
    res.send(students);
});

//Borrar un estudiante
app.delete('api/students/:id', (req, res)=>{
    const students = s.find(c => c.id === parseInt(req.params.id));
    if(!students) return res.status(404).send('Nopiti no');

    const index = s.indexOf(students);
    s.splice(students, 1);
    res.send(students);
});

const port = process.env.port || 80;
app.listen(port, () => console.log(`Escuchando en puerto ${port}..`));